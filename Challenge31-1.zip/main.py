Forwarded

def linear search product (product list,target product):

indicies=[]

for index, product in enumerate

(product list):

if product==target product:

return indicies #example usage:

products=["shoes","boot","loafer","sh oes","sandel","shoes"]

target="shoes"

target 2="apple"

return-linear search product

(products,target)

print(result)