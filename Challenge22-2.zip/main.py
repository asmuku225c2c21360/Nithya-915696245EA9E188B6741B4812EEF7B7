#define the base class

class player:

def play (self):

print ("the player is playing cricket.") #define the derived class player class batsman (player):

def play (self)

print ("The batsman is batting.") #define the derived class bowler

class bowler (player):

def play(self):

print("the bowler is bowling"):

#create objects of batsman and bowler

classes

batsman-batsman()

bowler-bowler()

#call the play{} method for each objects

batsman play()

bowler play()